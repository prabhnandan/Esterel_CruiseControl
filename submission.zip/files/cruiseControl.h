#define PedalsMin 3.00
#define SpeedMin 30.00
#define SpeedMax 150.00

#define Zero 0.00

#define SpeedInc 2.50

float regulateThrottle(int isGoingOn, float cruiseSpeed, float vehicleSpeed);