Cruise Control System

Works only on Ubuntu, tested on FlexIT Ubunutu VM.

Instructions:
- Open terminal and cd to "../files/"
- Run the command "make cruiseControl.xes"
- Run the command "./cruiseControl.xes"
- Use the simulator main panel to input as desired